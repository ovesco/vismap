import Pin from './assets/icon.png';

export const icon = L => L.icon({
  iconAnchor: [13, 38],
  popupAnchor: [-3, -45],
  iconUrl: Pin,
});

export const zzz = 2;
